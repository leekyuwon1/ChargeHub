var express = require('express');
var router = express.Router();
var db = require('./db');

router.post('/login_process_mobile', function (request, response) {
    var id = request.body.id;
    var pw = request.body.pw;

    if (id && pw) {             // id와 pw가 입력되었는지 확인
        db.query('SELECT * FROM usertable WHERE username = ? AND password = ?', [id, pw], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {       // db에서의 반환값이 있으면 로그인 성공
                response.statusCode = 200;
                request.session.is_logined = true;      // 세션 정보 갱신
                request.session.nickname = id;
                request.session.save(function () {
                    response.send(`{"result":true}`);
                });
            } else {              
                response.statusCode = 403;
                response.send(`{"result":false}`);
            }            
        });

    } else {
        response.statusCode = 204;
        response.send(`{"result":false}`);
    }
});


// 회원가입 프로세스
router.post('/register_process_mobile', function(request, response) {    

    var id = request.body.id;
    var pw = request.body.pw;    
    var pw2 = request.body.pw2;

    if (id && pw && pw2) {
        
        db.query('SELECT * FROM usertable WHERE username = ?', [id], function(error, results, fields) { // DB에 같은 이름의 회원아이디가 있는지 확인
            if (error) throw error;
            if (results.length <= 0 && pw == pw2) {     // DB에 같은 이름의 회원아이디가 없고, 비밀번호가 올바르게 입력된 경우 

                db.query('INSERT INTO usertable (username, password) VALUES(?,?)', [id, pw], function (error, data) {
                    response.statusCode = 200;
                    if (error) throw error2;
                    response.send(`{"result":true}`);
                });
            } else if (pw != pw2) {        // 비밀번호가 올바르게 입력되지 않은 경우
                response.statusCode = 405;
                response.send(`{"result":false}`);    
            }
            else {                        
                response.statusCode = 409;// DB에 같은 이름의 회원아이디가 있는 경우
                response.send(`{"result":false}`);    
            }            
        });

    } else {        // 입력되지 않은 정보가 있는 경우
        response.send(`{"result":false}`);
    }
});


module.exports = router;