//package com.lkw.searchbar.net;
//
//import com.google.gson.Gson;
//import com.google.gson.GsonBuilder;
//
//public class Net {
//    private static Net ourinstance = new Net();
//
//    public static Net getInstance(){
//        return ourinstance;
//    }
//
//    Gson gson = new GsonBuilder().setLenient().create();
//
//}
