package com.lkw.searchbar.utils;

public class Intentkey {
    //카테고리별로 찾은 모델 정보
    public static final String CATEGOTY_SEARCH_MODEL_EXTRA1 = "CATEGOTY_SEARCH_MODEL_EXTRA1";
    public static final String CATEGOTY_SEARCH_MODEL_EXTRA2 = "CATEGOTY_SEARCH_MODEL_EXTRA2";
    public static final String CATEGOTY_SEARCH_MODEL_EXTRA3 = "CATEGOTY_SEARCH_MODEL_EXTRA3";
    public static final String CATEGOTY_SEARCH_MODEL_EXTRA4 = "CATEGOTY_SEARCH_MODEL_EXTRA4";
    public static final String CATEGOTY_SEARCH_MODEL_EXTRA5 = "CATEGOTY_SEARCH_MODEL_EXTRA5";
    public static final String CATEGOTY_SEARCH_MODEL_EXTRA6 = "CATEGOTY_SEARCH_MODEL_EXTRA6";
    public static final String CATEGOTY_SEARCH_MODEL_EXTRA7 = "CATEGOTY_SEARCH_MODEL_EXTRA7";
    public static final String CATEGOTY_SEARCH_MODEL_EXTRA8 = "CATEGOTY_SEARCH_MODEL_EXTRA8";
    public static final String CATEGOTY_SEARCH_MODEL_EXTRA9 = "CATEGOTY_SEARCH_MODEL_EXTRA9";
    //PollItem클릭시 해당 모델 상세보기로 전달
    public static final String PLACE_SEARCH_DETAIL_EXTRA = "PLACE_SEARCH_DETAIL_EXTRA";

}
