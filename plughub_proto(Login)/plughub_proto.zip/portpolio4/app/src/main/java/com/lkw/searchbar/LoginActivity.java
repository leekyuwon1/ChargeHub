package com.lkw.searchbar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.lkw.searchbar.retrofit_login.RetrofitInterfaceLog;
import com.lkw.searchbar.retrofit_login.model.LoginResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginActivity extends AppCompatActivity {

    private EditText loginIdEdt;
    private EditText loginPwEdt;

    private Retrofit retrofit;
    private RetrofitInterfaceLog loginRetro;
    private Call<LoginResponse> call;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        loginIdEdt = findViewById(R.id.login_ID);
        loginPwEdt = findViewById(R.id.login_PW);
        findViewById(R.id.login_btn).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                login();
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);

            }
//            startActivity(intent);


        });

        findViewById(R.id.signup_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });


        // Retrofit 객체 생성
        retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.5.3:18021/") //안드로이드 에뮬레이터로 접근 하기위한 특수 주소
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        // Retrofit 인터페이스 생성
        loginRetro = retrofit.create(RetrofitInterfaceLog.class);
    }

    void login() {
        // 데이터베이스 에서 데이터 조회
        call = loginRetro.login(
                loginIdEdt.getText().toString(),
                loginPwEdt.getText().toString()
        );//response.isSuccessful()
        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.code() == 200) {
                    LoginResponse loginResponse = response.body();
                    Toast.makeText(getApplicationContext(), "로그인 성공", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);

                } else if(response.code() == 204){
                    Toast.makeText(getApplicationContext(), "아이디와 비밀번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
                }else{
                    // 서버 응답 실패
                    Log.e("Retrofit", "Server response error");
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                // 통신 실패
                Log.e("Retrofit", "Communication failure: " + t.getMessage());

            }

        });
    }
}


//                    List<data_model_log> resultList = response.body();
//                    if (resultList != null && !resultList.isEmpty()) {
//                        data_model_log results = resultList.get(0);
//
//                        // 데이터 처리
//                        String str =
//                                results.getID() + "\n" +
//                                        results.getPW() + "\n";
//
//                        editText.setText(str);
//                    }