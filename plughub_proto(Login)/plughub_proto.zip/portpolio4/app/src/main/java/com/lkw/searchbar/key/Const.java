package com.lkw.searchbar.key;

public class Const {
    public static final String RETROFIT_KAKAO_BASE_URL = "https://dapi.kakao.com/";
    public static final String KAKAO_MAP_REST_API_APP_KEY = "a65e51f81c1bfd707b00f82ddf38cd0e";
}

